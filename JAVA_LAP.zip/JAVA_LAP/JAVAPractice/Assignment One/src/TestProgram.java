public class TestProgram {
    public static void main(String[] args) {
        Person person = new Person("Naima Hassan", "154 Waddada Koowaad", "2547766870", "naima@example.com");
        Student student = new Student("Abdisamiic Ali", "155 Waddada Labaad", "52547766989", "abdi@example.com", Student.FRESHMAN);
        MyDate dateHired = new MyDate("2024-01-01"); // Assuming this is correctly implemented
        Employee employee = new Employee("Mohamed Hassan", "156 Waddada Saddexaad", "2547778848", "osman@example.com", "Xafiiska 2aad", 2000, dateHired);
        Faculty faculty = new Faculty("Tasniim Mohamed", "157", "252 61776687", "tasnim@gmai.com","Xafiiska 4aad", 15000, dateHired, "100","1");
        Staff staff = new Staff("Zakia Hassan", "Sales", "252 61775589", "zakia@gmail.com","Xafiisla 3aad", 3000, dateHired, "Manager");

        System.out.println(person);
        System.out.println(student);
        System.out.println(employee);
        System.out.println(faculty);
        System.out.println(staff);

    }
}
