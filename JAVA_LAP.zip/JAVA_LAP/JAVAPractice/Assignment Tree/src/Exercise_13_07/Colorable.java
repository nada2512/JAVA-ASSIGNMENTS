package Exercise_13_07;

public interface Colorable {
    void howToColor();
}
